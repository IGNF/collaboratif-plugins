# assistant-dfci-plugin-qgis
Aide à la saisie des attributs DFCI sur les tronçons de route.
