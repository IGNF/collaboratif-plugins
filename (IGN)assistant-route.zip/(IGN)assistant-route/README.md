# assistant-route-plugin-qgis
Aide à la saisie des attributs sur les tronçons de route (jeux d'attributs)
