LAYER_ROUTE = "troncon_de_route"

TITRE_INTERFACE = "Contribution directe BDUni (ROUTE)"
VERSION = "v1.4.0"
PLUGIN_ESPACE_CO = "ign_espace_collaboratif"
PLUGIN_CHE_PLUS_COURT = "(IGN)chemin-le-plus-court"

# champs
IDENTIFIANT = "id"
NATURE = "nature"
IMPORTANCE = "importance"
SENS = "sens_de_circulation"
NB_VOIES = "nombre_de_voies"
LARGEUR = "largeur_de_chaussee"
ITI_VERT = "itineraire_vert"
ACCES = "acces_vehicule_leger"

RESTRICTION_HAUTEUR = "restriction_de_hauteur"
RESTRICTION_LARGEUR = "restriction_de_largeur"
RESTRICTION_LONGUEUR = "restriction_de_longueur"
RESTRICTION_POIDS_ESSIEU = "restriction_de_poids_par_essieu"
RESTRICTION_POIDS_TOTAL = "restriction_de_poids_total"

REGEX_LARGEUR  = r"^\d{1,2}(\.\d)?$"
REGEX_RESTR_HAUTEUR = "^$|^(([1-9])(\.[0-9])([05]){0,1})$"
REGEX_RESTR_LARGEUR = "^$|^(([1-5])(\.[0-9])([05]){0,1})$"
REGEX_RESTR_LONGUEUR = "^$|^(([4-9]|1[0-9]|2[0-5])(\.[05](0)){0,1})$"
REGEX_RESTR_POIDS_ESSIEU = "^$|^(1\.[05]0|([2-9]|[1][0-9])(\.[05]0){0,1})$"
REGEX_RESTR_POIDS_TOTAL = "^$|^(1\.[05]0|([2-9]|[1-4][0-9]|5[0-7])(\.[05]0){0,1})$"

LIST_BTN_NATURE = ["pushButtonRte2Chaussee", "pushButtonRte1Chaussee", "pushButtonEmpierree",
                              "pushButtonChemin", "pushButtonSentier", "pushButtonRondpoint"]
LIST_BTN_LARGEUR = ["lineEditLargeur"]
LIST_BTN_NBVOIES = ["pushButton3voies", "pushButton2voies", "pushButton1voie", "pushButtonVoieSansObjet"]
LIST_BTN_IMPORTANCE = ["pushButtonImportance1", "pushButtonImportance2", "pushButtonImportance3",
                                  "pushButtonImportance4", "pushButtonImportance5", "pushButtonImportance6"]
LIST_BTN_SENS = ["pushButtonDoubleSens", "pushButtonSensUnique", "pushButtonInverserSens",
                            "pushButtonSensSansObjet"
    # , "pushButtonSensSansVal"
                 ]
LIST_BTN_ACCES = ["pushButtonAccesLibre", "pushButtonAccesRestreint", "pushButtonAccesImpossible"]
LIST_LINEEDIT_RESTR = ["lineEditRestrHauteur","lineEditRestrLargeur","lineEditRestrLongueur",
                                   "lineEditRestrPoidsEssieu","lineEditRestrPoidsTotal"]


DICO_CHAMP_BTN = {NATURE : LIST_BTN_NATURE,
                  NB_VOIES : LIST_BTN_NBVOIES ,
                  LARGEUR : LIST_BTN_LARGEUR,
                  IMPORTANCE : LIST_BTN_IMPORTANCE,
                  SENS : LIST_BTN_SENS,
                  ACCES : LIST_BTN_ACCES
                  }



# attributs
SANS_OBJET = "Sans objet"
DOUBLE_SENS = "Double sens"
SENS_DIRECT = "Sens direct"
SENS_INVERSE = "Sens inverse"
SENS_UNIQUE = "Sens unique"
ACCES_LIBRE = "Libre"
ACCES_IMPOSSIBLE = "Physiquement impossible"
ACCES_RESTREINT = "Restreint aux ayants droit"
RTE_2_CHAUSSEES = "Route à 2 chaussées"
RTE_1_CHAUSSEE = "Route à 1 chaussée"
RTE_EMPIERREE = "Route empierrée"
ROND_POINT = "Rond-point"
CHEMIN = "Chemin"
SENTIER = "Sentier"

CLEABS = "cleabs"

# 0 : bouton clické → fond rose
# 1 : valeur de l'objet → fond vert
# 2 : valeur par defaut → pas de fond
# 3 : couleur fond label → fond bleu clair
# 4 : couleur fond bouton validation (orange)
# 5 : aspect pour le line edit largeur (fond rose)
# 6 : valeur interdite
CUSTOM_WIDGETS = ("background-color: #ff8080 ;font-weight: bold",
                  "background-color: #2ab51a ;font-weight: bold",
                  "background-color: None ;font-weight: bold",
                  "background-color: #cccccc",
                  "background-color: #df920d",
                  "background-color: #ff8080 ;font-weight: bold",
                  "background-color: None ;font-weight: bold"
                  )

# TEST
# 0 : pas de fond
# 1 : cliqué --> fond rose
CUSTOM_RADIOBOX = (
    """
            QRadioButton {background-color: #4CAF50;color: black;font-weight: bold}
            QRadioButton::indicator {width: 0px;height: 0px;}
            QRadioButton:checked {background-color: #ff8080;}
            }
        """,

    """ QRadioButton  {border: 2px solid #4CAF50;  
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                text-align: center;}
            QRadioButton ::indicator {width: 0px;height: 0px;}
            QRadioButton :checked {background-color: blue;}"""
)
