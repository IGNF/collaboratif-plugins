# Altibonne

* Visualisation d'un profil
* Modification des tous les z d'un tronçon et/ou des sommets sélectionnés

Prérequis : Le "plugin\_maitre" doit obligatoirement être installé.
Lien vers le plugin maître : [maitre-qgis-plugin sur GitHub](https://github.com/IGNF/maitre-qgis-plugin)

