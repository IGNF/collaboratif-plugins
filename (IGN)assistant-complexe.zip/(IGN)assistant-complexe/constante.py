
TITRE = "Assistant complexe"
VERSION = "v1.1.1"

LAYER_ESPACE_CO = ["troncon_de_route","route_numerotee_ou_nommee"]

LIEN_VERS_RTE_NOMMEE = "liens_vers_route_nommee"

CLEABS = "cleabs"
LIST_AUTRE_CHAMPS = ["type_de_route","gestionnaire","numero","toponyme"]