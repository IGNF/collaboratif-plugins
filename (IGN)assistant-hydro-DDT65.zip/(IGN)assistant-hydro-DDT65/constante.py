LAYER_HYDRO = "troncon_hydrographique"

TITRE_INTERFACE = "Contribution directe BDUni (HYDRO)"
VERSION = "v1.1.0"

PLUGIN_ESPACE_CO = "ign_espace_collaboratif"

CLEABS = "cleabs"
NATURE = "nature"
POS_SOL = "position_par_rapport_au_sol"
INVENT_PE = "inventaire_police_de_l_eau"
ID_PE = "identifiant_police_de_l_eau"
INVENT_BCAE = "inventaire_bcae"
ID_BCAE = "identifiant_bcae"
CPX_TOPONYME = "cpx_toponyme_de_cours_d_eau"

EXPERTENCOURS = "Expertise en cours"

FOND_DIAL = "background-color:#d3ddff"

# 0 : bouton clické → fond rose
# 1 : valeur de l'objet → fond vert
# 2 : valeur par defaut → pas de fond
# 3 : couleur fond label → fond gris clair
# 4 : couleur fond bouton validation (orange)
CUSTOM_WIDGETS = ("background-color: #ff8080 ;font-weight: bold",
                  "background-color: #2ab51a ;font-weight: bold",
                  "background-color: None",
                  "background-color: #dcdcdc",
                  "background-color: #df920d"
                  )

# CUSTOM_WIDGETS = ("background-color: #748ef1 ;font-weight: bold",
#                   "background-color: #2ab51a ;font-weight: bold",
#                   "background-color: None",
#                   # "background-color: #cdcdcd",
#                     "background-color: #b2c3ff",
#                   "background-color: #df920d"
#                   )

LISTVALEURNATURE = ["Aqueduc", "Conduit forcé", "Delta", "Ecoulement canalisé", "Ecoulement endoréique",
                    "Ecoulement hyporhéique", "Ecoulement karstique", "Ecoulement phréatique",
                    "Estuaire", "Glacier, névé", "Inconnue", "Lac", "Lagune", "Mangrove", "Marais",
                    "Mare", "Plan d'eau de gravière", "Plan d'eau de mine", "Ravine", "Retenue",
                    "Retenue-barrage", "Retenue-bassin portuaire", "Retenue-digue",
                    "Réservoir-bassin", "Réservoir-bassin d'orage", "Réservoir-bassin piscicole"]
