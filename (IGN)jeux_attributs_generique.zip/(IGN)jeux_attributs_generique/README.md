# Jeux d'attributs générique

Cet assistant permet de gérer de modifier des attributs.

Il s'adapte à tous les modèles.



Prérequis : Le "plugin\_maitre" doit obligatoirement être installé.
Lien vers le plugin maître : [maitre-qgis-plugin sur GitHub](https://github.com/IGNF/maitre-qgis-plugin)

