import os

TITRE = "Jeux d'attributs générique"
VERSION = "v1.2.0"
PLUGIN_CHE_PLUS_COURT = "(IGN)chemin-le-plus-court"
PLUGIN_CHE_SENS_NUM = "(IGN)sens_numerisation"

SEPARATION_TOOLTIP = "\t\U0001F846\t"
CLIN_OEIL = "\U0001F609"
NB_CHAMP_MAX = 20

TAILLE_BTN_DEFAUT = 30
TAILLE_FONT_DEFAUT = 8

CHAMP_NON_PRIS_EN_COMPTE = ["id_sqlite_1gnQg1s","geometrie"]

PATH_REP = f"{os.path.dirname(__file__)}"
PATHICON = os.path.join(os.path.dirname(__file__),"icons" ,"icon_principal.png")
PATHICON_FILTRE = os.path.join(os.path.dirname(__file__),"icons" ,"filtre.png")
PATHICON_PARAM = os.path.join(os.path.dirname(__file__),"icons" ,"param.png")
PATHICON_IMPORT = os.path.join(os.path.dirname(__file__),"icons" ,"importer.png")
PATHICON_EXPORT = os.path.join(os.path.dirname(__file__),"icons" ,"exporter.png")
PATHICON_SENS_NUM = os.path.join(os.path.dirname(__file__),"icons" ,"sens_num.png")
PATHICON_CHE_COURT = os.path.join(os.path.dirname(__file__),"icons" ,"chemin_court.png")
PATHICON_APROPOS = os.path.join(os.path.dirname(__file__),"icons" ,"apropos.png")
PATHJSON = os.path.join(os.path.dirname(__file__),"JSON","config.json")
PATHJSONPARAM = os.path.join(os.path.dirname(__file__),"JSON","param.json")




