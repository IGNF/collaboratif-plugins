# VueZ

Affichage des altitudes (Z) de tous les sommets des entités d’un layer.
Le layer peut être de n’importe quel type (ponctuel, ligne, polyligne, polygone).

La visualisation se base sur le layer actif et est limitée à la zone visible à l’écran.
Il suffit de relancer le plugin si la zone visible a changé.

Prérequis : Le "plugin\_maitre" doit obligatoirement être installé.
Lien vers le plugin maître : [maitre-qgis-plugin sur GitHub](https://github.com/IGNF/maitre-qgis-plugin)

