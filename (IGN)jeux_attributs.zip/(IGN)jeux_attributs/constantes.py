import os

SEPARATION_TOOLTIP = "\t\U0001F846\t"


PATHJSON = os.path.join(os.path.dirname(__file__),"config", "config_btn.json")
PATH_JSON_PARAMETRES = os.path.join(os.path.dirname(__file__), "config", "parametres.json")
PATH_ICON_CONFIG = os.path.join(os.path.dirname(__file__), "icons", "config.png")
PATH_ICON_INTERFACE = os.path.join(os.path.dirname(__file__), "icons", "icon_principal.png")
PATH_REP_ICON_BTN = os.path.join(os.path.dirname(__file__),"config", "icons_btn")