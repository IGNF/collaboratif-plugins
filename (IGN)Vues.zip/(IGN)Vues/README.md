# vues-plugin-qgis
Gestion des vues intégrée dans la barre d'état de QGIS.
Prérequis : Le "plugin_maitre" doit obligatoirement être installé.
Lien vers le plugin maître : [maitre-qgis-plugin sur GitHub](https://github.com/IGNF/maitre-qgis-plugin)
