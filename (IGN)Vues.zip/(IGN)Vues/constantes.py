HAUTEUR_BTN = 18

REP_VUES = "VUES"
XML_VUES = "vues.xml"
FIC_POS = "vue_active.txt"
VUE_DEFAUT = "courant"

# une ou plusieurs valeurs parmi : mCoordsEdit, mScaleWidget, mMagnifierWidget, mRotationLabel, mRotationEdit,
# mRenderSuppressionCBox, mOntheFlyProjectionStatusButton, mMessageLogViewerButton
LIST_VUES_QGIS_A_GARDER = ["mOntheFlyProjectionStatusButton","mScaleWidget"]